import controller.InicioController;

public class Main {
	
	public static void main(String[] args) {
		(new InicioController()).init();
	}
}
