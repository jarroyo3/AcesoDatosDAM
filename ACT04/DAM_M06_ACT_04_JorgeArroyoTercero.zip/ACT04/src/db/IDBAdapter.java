package db;

public interface IDBAdapter {

}
